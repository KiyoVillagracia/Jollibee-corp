
function validateLogin() {
  const user = document.getElementById("username").value;
  const pass = document.getElementById("password").value;

  if (user === "admin" && pass === "jollibee123") {
    alert("Login successful!");
    window.location.href = "index.html";
    return false;
  } else {
    alert("Invalid credentials. Try again.");
    return false;
  }
}
